const express = require('express');
const cors = require('cors');
const admin = require('firebase-admin');
const serviceAccount = require('../firebase/service-account.json');

// Initialize Firebase Admin
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Firestore references
const db = admin.firestore();
const usersRef = db.collection('users');
const institutionsRef = db.collection('institutions');
const learnersRef = db.collection('learners');
const teachersRef = db.collection('teachers');
const attendancesRef = db.collection('attendances');
const performancesRef = db.collection('performances');
const subscriptionsRef = db.collection('subscriptions');
const vouchersRef = db.collection('vouchers');

// Auth middleware
const authenticateUser = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const token = authHeader.split('Bearer ')[1];
  try {
    const decodedToken = await admin.auth().verifyIdToken(token);
    req.user = decodedToken;
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    return res.status(401).json({ error: 'Unauthorized' });
  }
};

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'API is running' });
});

// Users
app.get('/api/users', authenticateUser, async (req, res) => {
  try {
    const snapshot = await usersRef.get();
    const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Institutions
app.get('/api/institutions', authenticateUser, async (req, res) => {
  try {
    const snapshot = await institutionsRef.get();
    const institutions = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    res.json(institutions);
  } catch (error) {
    console.error('Error fetching institutions:', error);
    res.status(500).json({ error: 'Failed to fetch institutions' });
  }
});

// Subscriptions
app.post('/api/subscriptions', authenticateUser, async (req, res) => {
  try {
    const { learnerId, parentId, duration } = req.body;
    
    // Calculate dates
    const now = new Date();
    const endDate = new Date(now);
    endDate.setDate(now.getDate() + (duration || 30)); // Default 30 days
    
    const subscriptionData = {
      learnerId,
      parentId,
      startDate: now.toISOString(),
      endDate: endDate.toISOString(),
      status: 'Active',
      createdAt: admin.firestore.FieldValue.serverTimestamp()
    };
    
    const docRef = await subscriptionsRef.add(subscriptionData);
    res.status(201).json({ id: docRef.id, ...subscriptionData });
  } catch (error) {
    console.error('Error creating subscription:', error);
    res.status(500).json({ error: 'Failed to create subscription' });
  }
});

// Vouchers
app.post('/api/vouchers/redeem', authenticateUser, async (req, res) => {
  try {
    const { code, userId } = req.body;
    
    const voucherQuery = await vouchersRef.where('code', '==', code).get();
    
    if (voucherQuery.empty) {
      return res.status(404).json({ error: 'Invalid voucher code' });
    }
    
    const voucherDoc = voucherQuery.docs[0];
    const voucher = { id: voucherDoc.id, ...voucherDoc.data() };
    
    if (voucher.isRedeemed) {
      return res.status(400).json({ error: 'Voucher already redeemed' });
    }
    
    await voucherDoc.ref.update({
      isRedeemed: true,
      redeemedBy: userId,
      redeemedOn: admin.firestore.FieldValue.serverTimestamp()
    });
    
    res.json({ success: true, credits: voucher.credits });
  } catch (error) {
    console.error('Error redeeming voucher:', error);
    res.status(500).json({ error: 'Failed to redeem voucher' });
  }
});

// AI Integration
app.post('/api/ai/generate-test', authenticateUser, async (req, res) => {
  try {
    const { subject, grade, topics, numberOfQuestions } = req.body;
    
    // This would call our AI service
    const aiResponse = await fetch(process.env.AI_SERVICE_URL || 'http://ai-service:8080/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ subject, grade, topics, numberOfQuestions }),
    });
    
    const testData = await aiResponse.json();
    res.json(testData);
  } catch (error) {
    console.error('Error generating test:', error);
    res.status(500).json({ error: 'Failed to generate test' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

module.exports = app;