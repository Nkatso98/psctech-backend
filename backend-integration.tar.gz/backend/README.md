# PSC Tech School Portal Backend Integration

This backend integration module provides the necessary server-side functionality for the PSC Tech School Management Portal, including API endpoints, Firebase integration, and AI testing capabilities.

## Directory Structure

```
backend/
├── api/
│   └── index.js          # Express API server
├── firebase/
│   ├── service-account.json    # Firebase service account credentials
│   └── firestore-rules.js      # Firestore security rules
├── ai/
│   └── test-generator.js       # AI test generation service
└── package.json          # Node.js dependencies
```

## Features

1. **Authentication & Authorization**
   - User authentication with Firebase Auth
   - Role-based access control

2. **Data Management**
   - CRUD operations for institutions, users, learners, teachers
   - Attendance and performance tracking
   - Subscription management

3. **AI Test Generation**
   - Generate educational tests based on subjects and topics
   - Grade completed tests and provide feedback
   - Generate personalized study materials

4. **Integration with Frontend**
   - RESTful API endpoints for all functionality
   - Secure JWT-based authentication

## Setup Instructions

1. **Environment Setup**

   Create a `.env` file in the backend directory with the following variables:

   ```
   PORT=5000
   NODE_ENV=development
   AI_SERVICE_URL=https://api.psctech.ai/v1
   AI_SERVICE_API_KEY=your_api_key_here
   ```

2. **Install Dependencies**

   ```bash
   cd backend
   npm install
   ```

3. **Run the Server**

   ```bash
   npm run dev
   ```

## API Documentation

### Authentication

- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration

### Users

- `GET /api/users` - Get all users
- `GET /api/users/:id` - Get user by ID

### Institutions

- `GET /api/institutions` - Get all institutions
- `GET /api/institutions/:id` - Get institution by ID

### Subscriptions

- `POST /api/subscriptions` - Create a new subscription
- `GET /api/subscriptions?learnerId=:id` - Get subscriptions by learner ID

### Vouchers

- `POST /api/vouchers/redeem` - Redeem a voucher code

### AI Test Generation

- `POST /api/ai/generate-test` - Generate a new test
- `POST /api/test-sessions/:id/submit` - Submit test answers for grading

## Firebase Configuration

Before deploying to production, replace the placeholder service account credentials in `firebase/service-account.json` with your actual Firebase service account key.

## Production Deployment

For production deployment, build the backend with proper environment variables and deploy to a Node.js hosting platform such as Vercel, Heroku, or Google Cloud Run.